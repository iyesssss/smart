<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ip']) && isset($_POST['active'])) {
    $ip = $_POST['ip'];
    $activityFile = 'user_activity.json';

    $activities = file_exists($activityFile) ? json_decode(file_get_contents($activityFile), true) : [];
    $activities[$ip] = time(); // Update the time of the last activity

    file_put_contents($activityFile, json_encode($activities));

    echo json_encode(['message' => 'Activity updated successfully.']);
} else {
    http_response_code(400); // Bad Request
    echo "Invalid request";
}
?>
