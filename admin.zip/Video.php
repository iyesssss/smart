<?php
// Get the IP address of the visitor/user
$user_ip = $_SERVER['REMOTE_ADDR'];

// Display the IP address
echo "Your IP address is: " . $user_ip;
?>
