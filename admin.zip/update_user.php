<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ip']) && isset($_POST['title'])) {
    $ip = $_POST['ip'];
    $title = $_POST['title'];
    $currentUserFile = 'current_users.txt';

    $currentUsers = file_exists($currentUserFile) ? file_get_contents($currentUserFile) : '';
    $currentUserArray = explode("\n", trim($currentUsers));
    $updatedUsers = [];

    // Update or add the IP and title
    $found = false;
    foreach ($currentUserArray as $user) {
        if (strpos($user, $ip) === 0) {
            $updatedUsers[] = "$ip - $title";
            $found = true;
        } else {
            $updatedUsers[] = $user;
        }
    }

    if (!$found) {
        $updatedUsers[] = "$ip - $title"; // Add new user if not found
    }

    // Save the updated list
    file_put_contents($currentUserFile, implode("\n", $updatedUsers));

    // Return a response
    header('Content-Type: application/json');
    echo json_encode(['message' => 'User info updated successfully.']);
} else {
    // Invalid request
    http_response_code(400); // Bad Request
    echo "Invalid request";
}
?>
