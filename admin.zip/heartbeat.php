<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ip'])) {
    $ip = $_POST['ip'];
    $heartbeatFile = 'heartbeats.json';

    // Load or initialize the heartbeat data
    $heartbeats = file_exists($heartbeatFile) ? json_decode(file_get_contents($heartbeatFile), true) : [];
    $heartbeats[$ip] = time(); // Update with current timestamp

    // Save back to the file
    file_put_contents($heartbeatFile, json_encode($heartbeats));

    header('Content-Type: application/json');
    echo json_encode(['message' => 'Heartbeat updated.']);
} else {
    http_response_code(400); // Bad Request
    echo "Invalid request";
}
