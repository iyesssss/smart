<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test</title>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to send the page title to the server
            function sendPageTitle() {
                const pageTitle = document.title; // This gets the title of the current page
                const ip = '<?php echo $_SERVER['REMOTE_ADDR']; ?>'; // Get the user's IP address from PHP
                
                fetch('update_user.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'ip=' + encodeURIComponent(ip) + '&title=' + encodeURIComponent(pageTitle)
                })
                .then(response => response.json())
                .then(data => console.log(data.message))
                .catch(error => console.error('Error:', error));
            }

            sendPageTitle(); // Call the function to send the title when the page loads
        });
		
		setInterval(() => {
    // Send a heartbeat signal
    fetch('heartbeat.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'ip=' + encodeURIComponent('<?php echo $_SERVER['REMOTE_ADDR']; ?>')
    })
    .then(response => response.json())
    .then(data => console.log('Heartbeat sent'))
    .catch(error => console.error('Error sending heartbeat:', error));
}, 5000); // Send heartbeat every 5 seconds


    </script>
</head>
<body>
    <?php
    $ip = $_SERVER['REMOTE_ADDR'];
    $currentUserFile = 'current_users.txt';

    $currentUsers = file_exists($currentUserFile) ? file_get_contents($currentUserFile) : '';
    $currentUserArray = explode("\n", trim($currentUsers));

    if (!in_array($ip, $currentUserArray)) {
        file_put_contents($currentUserFile, $ip . "\n", FILE_APPEND);
    }

    register_shutdown_function(function() use ($ip, $currentUserFile, $currentUserArray) {
        if(($key = array_search($ip, $currentUserArray)) !== false) {
            unset($currentUserArray[$key]);
            file_put_contents($currentUserFile, implode("\n", $currentUserArray));
        }
    });
    ?>

    <div id="contentContainer"></div>

    <script>
    setInterval(() => {
        fetch('check_command.php?ip=<?php echo $ip; ?>')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('contentContainer');
            if (data.command === 'showLoading') {
                container.innerHTML = '<img src="loading.gif" alt="Loading...">';
            } else if (data.command === 'showTemplate') {
                container.innerHTML = data.htmlContent;
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }, 5000);
	
	
    </script>
</body>
</html>
