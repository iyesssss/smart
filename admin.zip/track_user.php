<?php
if (isset($_GET['ip']) && isset($_GET['title'])) {
    $ip = $_GET['ip'];
    $title = $_GET['title'];
    $record = $ip . ' - ' . $title;

    file_put_contents('debug_log.txt', "Received: $record\n", FILE_APPEND); // Debug log
    file_put_contents('current_users.txt', $record . "\n", FILE_APPEND);
} else {
    file_put_contents('debug_log.txt', "Missing IP or title\n", FILE_APPEND); // Debug log for errors
}
?>
